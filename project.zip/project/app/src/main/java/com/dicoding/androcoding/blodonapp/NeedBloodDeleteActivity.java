package com.dicoding.androcoding.blodonapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

public class NeedBloodDeleteActivity extends AppCompatActivity {

    TextView delneedblood;
    Button btn_delete1, btn_cancel1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_need_blood_delete);

        btn_delete1 = findViewById(R.id.btn_delete1);
        btn_cancel1 = findViewById(R.id.btn_cancel1);
        delneedblood = findViewById(R.id.delneedblood);
        final Bundle bundle = getIntent().getExtras();
        delneedblood.setText("Apakah Anda ingin menghapus"+bundle.getString("nama_produk"));
    }
}