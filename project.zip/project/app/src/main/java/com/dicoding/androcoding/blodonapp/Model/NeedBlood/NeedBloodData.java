package com.dicoding.androcoding.blodonapp.Model.NeedBlood;

public class NeedBloodData {
    public static boolean getId_needblood;
    private int id_needblood;
    private String nama, waktu, pesan, lokasi;

    public int getId_needblood() { return id_needblood; }

    public void setId_needblood(int id_needblood) {
        this.id_needblood = id_needblood;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getWaktu() {
        return waktu;
    }

    public void setWaktu(String waktu) {
        this.waktu = waktu;
    }

    public String getPesan() {
        return pesan;
    }

    public void setPesan(String pesan) {
        this.pesan = pesan;
    }

    public String getLokasi() {
        return lokasi;
    }

    public void setLokasi(String lokasi) {
        this.lokasi = lokasi;
    }
}
