package com.dicoding.androcoding.blodonapp;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Toast;


import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class NeedBloodEditActivity extends AppCompatActivity {

    EditText ed_nama, ed_waktu1, ed_lokasi1;
    Button btedit_needblood;
    Calendar myCalendar1;
    DatePickerDialog.OnDateSetListener date1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_need_blood_edit);

        ed_nama = findViewById(R.id.ed_nama);
        ed_waktu1 = findViewById(R.id.ed_waktu1);
        ed_lokasi1 = findViewById(R.id.ed_lokasi1);
        btedit_needblood = findViewById(R.id.btedit_needblood);

        final Bundle bundle = getIntent().getExtras();
        ed_nama.setText(bundle.getString("Nama Lengkap"));
        ed_waktu1.setText(bundle.getString("Waktu update"));
        ed_lokasi1.setText(bundle.getString("Lokasi"));
        btedit_needblood = findViewById(R.id.btedit_needblood);

        myCalendar1 = Calendar.getInstance();
        date1 = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                myCalendar1.set(Calendar.YEAR, year);
                myCalendar1.set(Calendar.MONTH, monthOfYear);
                myCalendar1.set(Calendar.DAY_OF_MONTH, dayOfMonth);

                String myFormat = "yyyy-MMMM-dd";
                SimpleDateFormat sdf1 = new SimpleDateFormat(myFormat, Locale.US);

                ed_waktu1.setText(sdf1.format(myCalendar1.getTime()));

            }
        };

        ed_waktu1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new DatePickerDialog(NeedBloodEditActivity.this, date1,
                        myCalendar1.get(Calendar.YEAR),
                        myCalendar1.get(Calendar.MONTH),
                        myCalendar1.get(Calendar.DAY_OF_MONTH)).show();

            }
        });

        btedit_needblood.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nama = ed_nama.getText().toString();
                String waktu = ed_waktu1.getText().toString();
                String lokasi = ed_lokasi1.getText().toString();
            }
        });

    }
}