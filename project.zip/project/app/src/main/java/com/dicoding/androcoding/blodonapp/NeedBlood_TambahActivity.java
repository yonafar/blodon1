package com.dicoding.androcoding.blodonapp;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.provider.Settings;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import com.dicoding.androcoding.blodonapp.API.ApiClient;
import com.dicoding.androcoding.blodonapp.API.ApiInterfaces;
import com.dicoding.androcoding.blodonapp.Model.NeedBlood.NeedBlood;
import com.dicoding.androcoding.blodonapp.R;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class NeedBlood_TambahActivity extends AppCompatActivity {

    EditText edaddnama, edaddwaktu, edaddpesan, edaddlokasi;
    Button btsub;
    Bitmap bitmap;
    Calendar mycalender1;
    DatePickerDialog.OnDateSetListener date1;
    String nama, waktu, pesan, lokasi;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_form_need_blood);

        if (getSupportActionBar() != null){
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        edaddnama = findViewById(R.id.edaddnama);
        edaddwaktu = findViewById(R.id.edaddwaktu);
        edaddpesan = findViewById(R.id.edaddpesan);
        edaddlokasi = findViewById(R.id.edaddlokasi);
        btsub = findViewById(R.id.btsub);

        //cek permission
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && ContextCompat.checkSelfPermission(this,
                Manifest.permission.READ_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {
            Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.parse("package:" + getPackageName()));
            finish();
            startActivity(intent);
            return;
        }

        mycalender1 =Calendar.getInstance();
        date1 = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                mycalender1.set(Calendar.YEAR, year);
                mycalender1.set(Calendar.MONTH, monthOfYear);
                mycalender1.set(Calendar.DAY_OF_MONTH, dayOfMonth);

                EditText waktu = findViewById(R.id.edaddwaktu);
                String myFormat = "yyyy-MMMM-dd";
                SimpleDateFormat sdf1 = new SimpleDateFormat(myFormat, Locale.US);

                waktu.setText(sdf1.format(mycalender1.getTime()));
            }
        };

        edaddwaktu.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.N)
            @Override
            public void onClick(View v) {
                new DatePickerDialog(NeedBlood_TambahActivity.this, date1,
                        mycalender1.get(Calendar.YEAR),
                        mycalender1.get(Calendar.MONTH),
                        mycalender1.get(Calendar.DAY_OF_MONTH)).show();
            }
        });

        btsub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                nama = edaddnama.getText().toString();
                waktu = edaddwaktu.getText().toString();
                pesan = edaddpesan.getText().toString();
                lokasi = edaddlokasi.getText().toString();

                if (nama.trim().equals("")) {
                    edaddnama.setError("Name Is Required");
                }
                if (waktu.trim().equals("")) {
                    edaddwaktu.setError("Time Must Be Filled");
                }
                if (pesan.trim().equals("")) {
                    edaddpesan.setError("Caption must be filled");
                }
                if (lokasi.trim().equals("")) {
                    edaddlokasi.setError("Location Is Required");
                } else {
                    addNeedBlood();
                }
            }
        });
    }

    private void addNeedBlood(){
        ByteArrayOutputStream byteArrayOutputStream1 = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, byteArrayOutputStream1);
        byte[] byteArray = byteArrayOutputStream1.toByteArray();

        final String encoded = Base64.encodeToString(byteArray, Base64.DEFAULT);
        Log.d("zzzResponse", encoded);

        ApiInterfaces apiInterfaces = ApiClient.getClient().create(ApiInterfaces.class);
        Call<NeedBlood> insertNeedBlood = apiInterfaces.addNeedBloodResponse(nama, waktu, pesan, lokasi, encoded);

        insertNeedBlood.enqueue(new Callback<NeedBlood>() {
            @Override
            public void onResponse(Call<NeedBlood> call, Response<NeedBlood> response) {
                if (response.isSuccessful()){

                    onBackPressed();
                }
                int code = response.body().getCode();
                String description = response.body().getDescription();

                //Toast.makeText(EventTambahActivity.this, "Code : "+code+" | Description : "+description, Toast.LENGTH_SHORT).show();
                finish();
            }

            @Override
            public void onFailure(Call<NeedBlood> call, Throwable t) {
                Toast.makeText(NeedBlood_TambahActivity.this, "Failed to connect the server" +t.getMessage(), Toast.LENGTH_SHORT).show();

            }
        });
    }
    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }
    // jika user telah memilih foto, proses menjadi bitmap dan tampilkan dalam preview

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 100 && resultCode == RESULT_OK && data != null) {

            //getting the image Uri
            Uri imageUri = data.getData();
            try {
                //getting bitmap object from uri
                bitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), imageUri);

            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}