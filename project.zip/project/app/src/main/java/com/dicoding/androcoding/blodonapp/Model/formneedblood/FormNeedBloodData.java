package com.dicoding.androcoding.blodonapp.Model.formneedblood;

public class FormNeedBloodData {
    private int id_form_needblood, id_needblood;
    private String full_name, blood_group, gender, age, phone_number,job;

    public int getId_form_needblood() {
        return id_form_needblood;
    }

    public void setId_form_needblood(int id_form_needblood) {
        this.id_form_needblood = id_form_needblood;
    }

    public int getId_needblood() {
        return id_needblood;
    }

    public void setId_needblood(int id_needblood) {
        this.id_needblood = id_needblood;
    }

    public String getFull_name() {
        return full_name;
    }

    public void setFull_name(String full_name) {
        this.full_name = full_name;
    }

    public String getBlood_group() {
        return blood_group;
    }

    public void setBlood_group(String blood_group) {
        this.blood_group = blood_group;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getAge() {
        return age;
    }

    public void setAge(String age) {
        this.age = age;
    }

    public String getPhone_number() {
        return phone_number;
    }

    public void setPhone_number(String phone_number) {
        this.phone_number = phone_number;
    }

    public String getJob() {
        return job;
    }

    public void setJob(String job) {
        this.job = job;
    }
}
