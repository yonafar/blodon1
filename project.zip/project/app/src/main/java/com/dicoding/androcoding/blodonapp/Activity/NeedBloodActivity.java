package com.dicoding.androcoding.blodonapp.Activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.dicoding.androcoding.blodonapp.API.ApiClient;
import com.dicoding.androcoding.blodonapp.API.ApiInterfaces;
import com.dicoding.androcoding.blodonapp.Adapter.AdapterNeedBlood;
import com.dicoding.androcoding.blodonapp.Model.NeedBlood.NeedBlood;
import com.dicoding.androcoding.blodonapp.Model.NeedBlood.NeedBloodData;
import com.dicoding.androcoding.blodonapp.NeedBlood_TambahActivity;
import com.dicoding.androcoding.blodonapp.R;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class NeedBloodActivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    private RecyclerView.Adapter adapter;
    private RecyclerView.LayoutManager layoutManager;
    private List<NeedBloodData> listNeedBlood = new ArrayList<>();
    private SwipeRefreshLayout swipeRefreshLayout;
    private ProgressBar progressBar;
    private FloatingActionButton btntambahblood;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_need_blood);

        btntambahblood = findViewById(R.id.btntambahblood);
        swipeRefreshLayout = findViewById(R.id.swipenb);
        progressBar = findViewById(R.id.pb_blood);

        recyclerView = findViewById(R.id.rv_blood);
        layoutManager = new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false);
        recyclerView.setLayoutManager(layoutManager);

        //setting swipe refresh layout
        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                swipeRefreshLayout.setRefreshing(true);
                SelectNeedBlood();
                swipeRefreshLayout.setRefreshing(false);

            }
        });

        if (getSupportActionBar() != null){
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        btntambahblood.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(NeedBloodActivity.this, NeedBlood_TambahActivity.class);
                startActivity(intent);
            }
        });
    }

    public void SelectNeedBlood(){

        //setting start progress bar
        progressBar.setVisibility(View.VISIBLE);

        ApiInterfaces apiInterfaces = ApiClient.getClient().create(ApiInterfaces.class);
        Call<NeedBlood> tampilNeedBlood = apiInterfaces.needbloodResponse();

        tampilNeedBlood.enqueue(new Callback<NeedBlood>() {
            @Override
            public void onResponse(Call<NeedBlood> call, Response<NeedBlood> response) {
                int code = response.body().getCode();
                String description = response.body().getDescription();

                //Toast.makeText(EventActivity.this, "Code : "+code+" | Description : "+description, Toast.LENGTH_SHORT).show();

                listNeedBlood = response.body().getResults();

                adapter = new AdapterNeedBlood(NeedBloodActivity.this, listNeedBlood);
                recyclerView.setAdapter(adapter);
                adapter.notifyDataSetChanged();

                //setting end progress bar
                progressBar.setVisibility(View.INVISIBLE);
            }

            @Override
            public void onFailure(Call<NeedBlood> call, Throwable t) {
                Toast.makeText(NeedBloodActivity.this, "Failed to connect the server"+t.getMessage(), Toast.LENGTH_SHORT).show();

                //setting end progress bar
                progressBar.setVisibility(View.INVISIBLE);

            }
        });
    }
    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }

    @Override
    protected void onResume() {
        super.onResume();
        SelectNeedBlood();

    }

}
