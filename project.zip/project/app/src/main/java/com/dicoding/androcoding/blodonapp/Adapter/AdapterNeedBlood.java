package com.dicoding.androcoding.blodonapp.Adapter;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.media.audiofx.AudioEffect;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;

import com.dicoding.androcoding.blodonapp.API.ApiClient;
import com.dicoding.androcoding.blodonapp.API.ApiInterfaces;
import com.dicoding.androcoding.blodonapp.Activity.EventActivity;
import com.dicoding.androcoding.blodonapp.Activity.FormEventActivity;
import com.dicoding.androcoding.blodonapp.Activity.Form_NeedBloodActivity;
import com.dicoding.androcoding.blodonapp.Activity.NeedBloodActivity;
import com.dicoding.androcoding.blodonapp.Model.NeedBlood.NeedBlood;
import com.dicoding.androcoding.blodonapp.Model.NeedBlood.NeedBloodData;
import com.dicoding.androcoding.blodonapp.Model.event.Event;
import com.dicoding.androcoding.blodonapp.Model.event.EventData;
import com.dicoding.androcoding.blodonapp.R;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AdapterNeedBlood extends RecyclerView.Adapter<AdapterNeedBlood.HolderData> {
    private Context ctx1;
    private List<NeedBloodData> listNeedBlood;
    private int id_needblood;

    public AdapterNeedBlood(Context ctx1, List<NeedBloodData> listNeedBlood) {
        this.ctx1 = ctx1;
        this.listNeedBlood = listNeedBlood;
    }
    @NonNull
    //Data dari item_event ke RecyclerView
    @Override
    public HolderData onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View layout = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_needblood, parent, false);
        HolderData holder = new HolderData(layout);
        return holder;

    }
    // memanggil model
    public void onBindViewHolder(@NonNull HolderData holder, int position) {
        final NeedBloodData needBloodData = listNeedBlood.get(position);

        holder.it_id.setText(String.valueOf(needBloodData.getId_needblood()));
        holder.it_username.setText(needBloodData.getNama());
        holder.it_waktu.setText(needBloodData.getWaktu());
        holder.it_pesan.setText(needBloodData.getPesan());
        holder.it_lokasi.setText(needBloodData.getLokasi());

        holder.it_register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ctx1, Form_NeedBloodActivity.class);
                intent.putExtra("id", needBloodData.getId_needblood());
                ctx1.startActivity(intent);
            }
        });
    }
    @Override
    public int getItemCount() {return listNeedBlood.size(); }

    public class HolderData extends RecyclerView.ViewHolder{
        TextView it_id, it_username, it_waktu, it_pesan, it_lokasi;
        Button it_register;
        String nama_lengkap;

        public HolderData(@NonNull View itemView) {
            super(itemView);

            it_id = itemView.findViewById(R.id.it_id);
            it_username = itemView.findViewById(R.id.it_username);
            it_waktu = itemView.findViewById(R.id.it_waktu);
            it_pesan = itemView.findViewById(R.id.it_pesan);
            it_lokasi = itemView.findViewById(R.id.it_lokasi);
            it_register = itemView.findViewById(R.id.it_register);

            itemView.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {
                    AlertDialog.Builder dialogpesan = new AlertDialog.Builder(ctx1);
                    dialogpesan.setMessage("Are you sure want to delete?");
                    dialogpesan.setCancelable(true);

                    id_needblood = Integer.parseInt(it_id.getText().toString());
                    dialogpesan.setPositiveButton("Delete", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            deleteNeedBlood(id_needblood, nama_lengkap);
                            dialogInterface.dismiss();
                            ((NeedBloodActivity)ctx1).SelectNeedBlood();
                        }
                    });

                    dialogpesan.show();

                    return false;
                }
            });
        }

        private void deleteNeedBlood(int id_needblood, String nama_lengkap) {
            ApiInterfaces apiInterfaces = ApiClient.getClient().create(ApiInterfaces.class);
            Call<NeedBlood> hapusNeedBlood = apiInterfaces.delNeedBloodResponse(id_needblood, nama_lengkap);

            hapusNeedBlood.enqueue(new Callback<NeedBlood>() {
                @Override
                public void onResponse(Call<NeedBlood> call, Response<NeedBlood> response) {
                    int code = response.body().getCode();
                    String description = response.body().getDescription();

                    Toast.makeText(ctx1, "Code : "+code+" | Description"+description, Toast.LENGTH_SHORT).show();

                }

                @Override
                public void onFailure(Call<NeedBlood> call, Throwable t) {
                    Toast.makeText(ctx1, "Failed to connect the server"+t.getMessage(), Toast.LENGTH_SHORT).show();

                }
            });
        }

    }
}
