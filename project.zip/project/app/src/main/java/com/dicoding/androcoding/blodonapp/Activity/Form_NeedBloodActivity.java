package com.dicoding.androcoding.blodonapp.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.dicoding.androcoding.blodonapp.API.ApiClient;
import com.dicoding.androcoding.blodonapp.API.ApiInterfaces;


import com.dicoding.androcoding.blodonapp.Model.formneedblood.FormNeedBlood;
import com.dicoding.androcoding.blodonapp.R;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class Form_NeedBloodActivity extends AppCompatActivity {

    EditText fe_fullname1, fe_bg1, fe_gender1, fe_age1, fe_phone1, fe_job1;
    Button btregisevent1;
    private String fullname, bloodgroup, gender, age, phone, job;
    private int id_needblood;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_need_blood_tambah);

        fe_fullname1 = findViewById(R.id.fe_fullname1);
        fe_bg1 = findViewById(R.id.fe_bg1);
        fe_gender1 = findViewById(R.id.fe_gender1);
        fe_age1 = findViewById(R.id.fe_age1);
        fe_phone1 = findViewById(R.id.fe_phone1);
        fe_job1 = findViewById(R.id.fe_job1);
        btregisevent1 = findViewById(R.id.btregisevent1);

        btregisevent1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fullname = fe_fullname1.getText().toString();
                bloodgroup = fe_bg1.getText().toString();
                gender = fe_gender1.getText().toString();
                age = fe_age1.getText().toString();
                phone = fe_phone1.getText().toString();
                job = fe_job1.getText().toString();

                if (fullname.trim().equals("")){
                    fe_fullname1.setError("Name Is Required");
                }
                else if (bloodgroup.trim().equals("")){
                    fe_bg1.setError("Blood Group Is Required");
                }
                else if (gender.trim().equals("")){
                    fe_gender1.setError("Gender Is Required");
                }
                else if (age.trim().equals("")){
                    fe_age1.setError("Age Is Required");
                }
                else if (phone.trim().equals("")){
                    fe_phone1.setError("Phone Number Must Be Field");
                }
                else if (job.trim().equals("")){
                    fe_job1.setError("Job Is Required");
                }
                else {
                    FormNeedBlood();
                }
            }
        });
    }

    private void FormNeedBlood() {
        int id = getIntent().getIntExtra("id", 0);
        ApiInterfaces apiInterfaces = ApiClient.getClient().create(ApiInterfaces.class);
        Call<FormNeedBlood> simpandata = apiInterfaces.addFormNeedBloodResponse(id, fullname, bloodgroup, gender, age, phone,job);

        simpandata.enqueue(new Callback<FormNeedBlood>() {
            @Override
            public void onResponse(Call<FormNeedBlood> call, Response<FormNeedBlood> response) {
                int code = response.body().getCode();
                String description = response.body().getDescription();
                finish();
                Toast.makeText(Form_NeedBloodActivity.this, "Register is Succesful", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onFailure(Call<FormNeedBlood> call, Throwable t) {
                Toast.makeText(Form_NeedBloodActivity.this, "Failed to connect the server"+t.getMessage(), Toast.LENGTH_SHORT).show();

            }
        });
    }
}