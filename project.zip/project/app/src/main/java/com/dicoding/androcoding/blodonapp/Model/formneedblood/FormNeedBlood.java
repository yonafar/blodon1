package com.dicoding.androcoding.blodonapp.Model.formneedblood;


import com.dicoding.androcoding.blodonapp.Model.event.EventData;
import com.dicoding.androcoding.blodonapp.Model.formEvent.FormEventData;

import java.util.List;

public class FormNeedBlood {
    private int code;
    private String description;
    private List<FormNeedBloodData> results;

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public List<FormNeedBloodData> getResults() {
        return results;
    }

    public void setResults(List<FormNeedBloodData> results) {
        this.results = results;
    }
}
