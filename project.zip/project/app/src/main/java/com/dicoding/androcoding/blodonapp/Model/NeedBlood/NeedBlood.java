package com.dicoding.androcoding.blodonapp.Model.NeedBlood;

import com.dicoding.androcoding.blodonapp.Model.event.EventData;

import java.util.List;

public class NeedBlood {
    private int code;
    private String description;
    private List<NeedBloodData> results;

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public List<NeedBloodData> getResults() {
        return results;
    }

    public void setResults(List<NeedBloodData> results) {
        this.results = results;
    }
}
